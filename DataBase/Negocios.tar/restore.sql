--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Negocios";
--
-- Name: Negocios; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Negocios" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Spanish_Peru.1252';


ALTER DATABASE "Negocios" OWNER TO postgres;

\connect "Negocios"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: compras; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA compras;


ALTER SCHEMA compras OWNER TO postgres;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: rrhh; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA rrhh;


ALTER SCHEMA rrhh OWNER TO postgres;

--
-- Name: ventas; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA ventas;


ALTER SCHEMA ventas OWNER TO postgres;

--
-- Name: eliminarclientesinpedidos(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.eliminarclientesinpedidos() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM p.fechapedido
    FROM ventas.clientes c
    inner JOIN ventas.pedidoscabe p ON p.idcliente = c.idcliente;

    -- Si el cliente no tiene pedidos, eliminarlo
    IF NOT FOUND THEN
        RAISE NOTICE 'El cliente ha sido eliminado correctamente.';
    ELSE
        RAISE NOTICE 'El cliente tiene pedidos y no se puede eliminar.';
    END IF;
    RETURN;
END
$$;


ALTER FUNCTION public.eliminarclientesinpedidos() OWNER TO postgres;

--
-- Name: listar_empeados_cargo_venta(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.listar_empeados_cargo_venta() RETURNS void
    LANGUAGE plpgsql
    AS $$
declare 
	reg  RECORD;
    cur_cargo CURSOR FOR select  c.descargo, c.idcargo from rrhh.cargos c;
begin
	for reg in cur_cargo loop
		 RAISE NOTICE 'Puesto: %', reg.descargo ;
		
			declare 
				reg1  RECORD;
			    cur_empleado CURSOR FOR select e.nomempleado, e.idempleado 
			    from rrhh.empleados e where e.idcargo = reg.idcargo;
			
			begin
				for reg1 in cur_empleado loop
					 RAISE NOTICE 'Empleado: %', reg1.nomempleado ;
					
					
					declare
						reg2  RECORD;
					    cur_producto CURSOR FOR select p3.nomproducto  from ventas.pedidoscabe p 
						inner join ventas.pedidosdeta p2 on p2.idpedido = p.idpedido 
						inner join compras.productos p3 on p3.idproducto = p2.idproducto 
						where p.idempleado = reg1.idempleado;
						
					begin
						
						for reg2 in cur_producto loop
							 RAISE NOTICE 'Nombre producto: %', reg2.nomproducto ;
					
						end loop;
					end;
					
					
				end loop;
			END;
		
		
		

		end loop;
	
    RETURN;
END
$$;


ALTER FUNCTION public.listar_empeados_cargo_venta() OWNER TO postgres;

--
-- Name: mostrar_usuario(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.mostrar_usuario(id_usuario character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
	reg  RECORD;
    cur_clientes CURSOR FOR select * from Ventas.pedidoscabe 
	where idcliente = id_usuario;
begin
	for reg in cur_clientes loop
		raise notice 'Cliente: %', reg.fechapedido;
	END LOOP;
   RETURN;
END
$$;


ALTER FUNCTION public.mostrar_usuario(id_usuario character varying) OWNER TO postgres;

--
-- Name: mostrar_usuario(character varying, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.mostrar_usuario(id_usuario character varying, fecha_producto timestamp without time zone) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
	reg  RECORD;
    cur_clientes CURSOR FOR select * from Ventas.pedidoscabe 
	where idcliente = id_usuario;
begin
	for reg in cur_clientes loop
		raise notice 'Cliente: %', reg.fechapedido;
	END LOOP;
   RETURN;
END
$$;


ALTER FUNCTION public.mostrar_usuario(id_usuario character varying, fecha_producto timestamp without time zone) OWNER TO postgres;

--
-- Name: mostrar_valores(character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.mostrar_valores(IN nombre_producto character varying)
    LANGUAGE plpgsql
    AS $$
declare 
n_nomproveedor compras.proveedores.nomproveedor%type;
n_dirproveedor compras.proveedores.dirproveedor%type;
n_carcontacto  compras.proveedores.carcontacto%type;
n_fonoproveedor compras.proveedores.fonoproveedor%type;

begin
	select p.nomproveedor , p.dirproveedor , p.carcontacto, p.fonoproveedor  from compras.proveedores p
	into n_nomproveedor, n_dirproveedor, n_carcontacto, n_fonoproveedor
	inner join compras.productos p2 on p.idproveedor = p2.idproveedor
	where p2.nomproducto = 'Te Dharamsala';

	RAISE NOTICE 'Nombre %', n_nomproveedor ;
	RAISE NOTICE 'DirProvedor %', n_dirproveedor ;
	RAISE NOTICE 'Carcontacto %', n_carcontacto ;
  	RAISE NOTICE 'Fono %', n_fonoproveedor ;
END;
$$;


ALTER PROCEDURE public.mostrar_valores(IN nombre_producto character varying) OWNER TO postgres;

--
-- Name: obtener_datos_pedido_producto(text); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.obtener_datos_pedido_producto(IN nombre_producto text)
    LANGUAGE plpgsql
    AS $$
DECLARE
    cliente_nombre text;
    cliente_direccion text;
    pedido_fecha timestamp;
BEGIN
    SELECT c.nomcliente, c.dircliente, p.fechapedido
    INTO cliente_nombre, cliente_direccion, pedido_fecha
    FROM ventas.clientes c
    INNER JOIN ventas.pedidoscabe p ON p.idcliente = c.idcliente
    INNER JOIN ventas.pedidosdeta p2 ON p2.idpedido = p.idpedido
    INNER JOIN compras.productos p3 ON p3.idproducto = p2.idproducto
    WHERE p3.nomproducto = nombre_producto;

    RAISE NOTICE 'Cliente: %', cliente_nombre;
    RAISE NOTICE 'Dirección: %', cliente_direccion;
    RAISE NOTICE 'Fecha de Pedido: %', pedido_fecha;
END
$$;


ALTER PROCEDURE public.obtener_datos_pedido_producto(IN nombre_producto text) OWNER TO postgres;

--
-- Name: obtener_total_pedidos(character varying, numeric, numeric); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.obtener_total_pedidos(IN cliente_id character varying, IN trimestre numeric, IN year_age numeric, OUT total_pedidos numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
  SELECT SUM(pd.preciounidad * pd.cantidad - (pd.preciounidad * pd.cantidad * pd.descuento))
  INTO total_pedidos
  FROM ventas.clientes c
  INNER JOIN ventas.pedidoscabe p ON c.idcliente = p.idcliente
  INNER JOIN ventas.pedidosdeta pd ON p.idpedido = pd.idpedido
  WHERE p.idcliente = cliente_id
    AND EXTRACT(quarter FROM p.fechapedido) = trimestre
    AND EXTRACT(year FROM p.fechapedido) = year_age;
END;
$$;


ALTER PROCEDURE public.obtener_total_pedidos(IN cliente_id character varying, IN trimestre numeric, IN year_age numeric, OUT total_pedidos numeric) OWNER TO postgres;

--
-- Name: procedimiento_valor_triaje(character varying, numeric, numeric); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.procedimiento_valor_triaje(IN id_cliente character varying, IN trimestre numeric, IN year_age numeric)
    LANGUAGE plpgsql
    AS $$
DECLARE
	reg RECORD;
	cur_clientes CURSOR FOR SELECT p.idcliente, count(p.idpedido) AS id_pedido, 
		sum(pd.preciounidad * pd.cantidad - (pd.preciounidad * pd.cantidad * pd.descuento)) AS total 
		FROM ventas.clientes c 
		INNER JOIN ventas.pedidoscabe p ON c.idcliente = p.idcliente 
		INNER JOIN ventas.pedidosdeta pd ON p.idpedido = pd.idpedido 
		WHERE p.idcliente = id_cliente AND extract(quarter FROM p.fechapedido) = trimestre
		AND extract(year FROM p.fechapedido) = year_age
		GROUP BY p.idcliente, p.idpedido;
BEGIN
	FOR reg IN cur_clientes LOOP 
		RAISE NOTICE 'Cliente: %', reg.idcliente;
		RAISE NOTICE 'Trimestre: %', reg.id_pedido;
		RAISE NOTICE 'Total: %', reg.total;
	END LOOP;
END
$$;


ALTER PROCEDURE public.procedimiento_valor_triaje(IN id_cliente character varying, IN trimestre numeric, IN year_age numeric) OWNER TO postgres;

--
-- Name: todo_valores(integer, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.todo_valores(id_usuario integer, porcentaje double precision) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare 
	reg RECORD;
	cur_empleado cursor FOR select e.nomempleado as Empleado, c.descargo as Cargo,
	e.feccontrata as Fecha_Ingreso, sum(p2.preciounidad) as Venta, (sum(p2.preciounidad) * porcentaje) as comision
	from rrhh.empleados e 
	inner join rrhh.cargos c on c.idcargo = e.idcargo
	inner join ventas.pedidoscabe p on p.idempleado = e.idempleado
	inner join ventas.pedidosdeta p2 on p2.idpedido = p.idpedido
	where e.idempleado  = id_usuario
	group by e.nomempleado, c.descargo,e.feccontrata;
begin 
	for reg in cur_empleado loop 
		
		 RAISE NOTICE 'Empleado     Cargo                  Fecha_Ingreso     Venta     Comisión ';
		 RAISE NOTICE '%     %    %    %    % ', reg.Empleado, reg.Cargo, reg.Fecha_Ingreso,  reg.Venta, reg.comision;
	end loop;
    RETURN;
END
$$;


ALTER FUNCTION public.todo_valores(id_usuario integer, porcentaje double precision) OWNER TO postgres;

--
-- Name: valor_triaje(character varying, numeric, numeric); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.valor_triaje(id_cliente character varying, trimestre numeric, year_age numeric) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
	reg  RECORD;
    cur_clientes CURSOR FOR select  p.idcliente, count (p.idpedido) as id_pedido, 
		sum(pd.preciounidad * pd.cantidad - (pd.preciounidad*pd.cantidad*pd.descuento)) as total 
		from ventas.clientes c 
		inner join ventas.pedidoscabe p on c.idcliente = p.idcliente 
		inner join ventas.pedidosdeta pd on p.idpedido = pd.idpedido 
		where p.idcliente = id_cliente and extract (quarter from p.fechapedido)=trimestre
		and extract (year from p.fechapedido) = year_age
		group by p.idcliente, p.idpedido;
begin
	for reg in cur_clientes loop 
		raise notice 'Cliente: %', reg.idcliente;
		raise notice 'Trimestre: %', reg.id_pedido;
		raise notice 'Total: %', reg.total;
		
	end loop;
   RETURN;
END
$$;


ALTER FUNCTION public.valor_triaje(id_cliente character varying, trimestre numeric, year_age numeric) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categorias; Type: TABLE; Schema: compras; Owner: postgres
--

CREATE TABLE compras.categorias (
    idcateria integer NOT NULL,
    nombrecateria character varying(15) NOT NULL,
    descripcion text
);


ALTER TABLE compras.categorias OWNER TO postgres;

--
-- Name: productos; Type: TABLE; Schema: compras; Owner: postgres
--

CREATE TABLE compras.productos (
    idproducto integer NOT NULL,
    nomproducto character varying(40) NOT NULL,
    idproveedor integer,
    idcateria integer,
    cantxunidad character varying(20) NOT NULL,
    preciounidad numeric(10,0) NOT NULL,
    unidadesenexistencia smallint NOT NULL,
    unidadesenpedido smallint NOT NULL
);


ALTER TABLE compras.productos OWNER TO postgres;

--
-- Name: proveedores; Type: TABLE; Schema: compras; Owner: postgres
--

CREATE TABLE compras.proveedores (
    idproveedor integer NOT NULL,
    nomproveedor character varying(40) NOT NULL,
    dirproveedor character varying(60) NOT NULL,
    nomcontacto character varying(80) NOT NULL,
    carcontacto character varying(50) NOT NULL,
    idpais character(3),
    fonoproveedor character varying(25) NOT NULL,
    faxproveedor character varying(25) NOT NULL
);


ALTER TABLE compras.proveedores OWNER TO postgres;

--
-- Name: cargos; Type: TABLE; Schema: rrhh; Owner: postgres
--

CREATE TABLE rrhh.cargos (
    idcargo integer NOT NULL,
    descargo character varying(30) NOT NULL
);


ALTER TABLE rrhh.cargos OWNER TO postgres;

--
-- Name: distritos; Type: TABLE; Schema: rrhh; Owner: postgres
--

CREATE TABLE rrhh.distritos (
    iddistrito integer NOT NULL,
    nomdistrito character varying(50) NOT NULL
);


ALTER TABLE rrhh.distritos OWNER TO postgres;

--
-- Name: empleados; Type: TABLE; Schema: rrhh; Owner: postgres
--

CREATE TABLE rrhh.empleados (
    idempleado integer NOT NULL,
    apeempleado character varying(50) NOT NULL,
    nomempleado character varying(50) NOT NULL,
    fecnac timestamp without time zone NOT NULL,
    dirempleado character varying(60) NOT NULL,
    iddistrito integer,
    fonoempleado character varying(15),
    idcargo integer,
    feccontrata timestamp without time zone NOT NULL
);


ALTER TABLE rrhh.empleados OWNER TO postgres;

--
-- Name: clientes; Type: TABLE; Schema: ventas; Owner: postgres
--

CREATE TABLE ventas.clientes (
    idcliente character varying(5) NOT NULL,
    nomcliente character varying(40) NOT NULL,
    dircliente character varying(60) NOT NULL,
    idpais character(3),
    fonocliente character varying(25) NOT NULL
);


ALTER TABLE ventas.clientes OWNER TO postgres;

--
-- Name: paises; Type: TABLE; Schema: ventas; Owner: postgres
--

CREATE TABLE ventas.paises (
    idpais character(3) NOT NULL,
    nombrepais character varying(40) NOT NULL
);


ALTER TABLE ventas.paises OWNER TO postgres;

--
-- Name: pedidoscabe; Type: TABLE; Schema: ventas; Owner: postgres
--

CREATE TABLE ventas.pedidoscabe (
    idpedido integer NOT NULL,
    idcliente character varying(5),
    idempleado integer,
    fechapedido timestamp without time zone DEFAULT now() NOT NULL,
    fechaentrega timestamp without time zone,
    fechaenvio timestamp without time zone,
    enviopedido character(1) DEFAULT 0,
    cantidapedido integer,
    destinatario character varying(40),
    dirdestinatario character varying(60),
    ciudestinatario character varying(60),
    refdestnatario character varying(60),
    depdestinatario character varying(60),
    paidestinatario character varying(60)
);


ALTER TABLE ventas.pedidoscabe OWNER TO postgres;

--
-- Name: pedidosdeta; Type: TABLE; Schema: ventas; Owner: postgres
--

CREATE TABLE ventas.pedidosdeta (
    idpedido integer,
    idproducto integer,
    preciounidad numeric(10,0) NOT NULL,
    cantidad smallint NOT NULL,
    descuento double precision NOT NULL
);


ALTER TABLE ventas.pedidosdeta OWNER TO postgres;

--
-- Data for Name: categorias; Type: TABLE DATA; Schema: compras; Owner: postgres
--

COPY compras.categorias (idcateria, nombrecateria, descripcion) FROM stdin;
\.
COPY compras.categorias (idcateria, nombrecateria, descripcion) FROM '$$PATH$$/3393.dat';

--
-- Data for Name: productos; Type: TABLE DATA; Schema: compras; Owner: postgres
--

COPY compras.productos (idproducto, nomproducto, idproveedor, idcateria, cantxunidad, preciounidad, unidadesenexistencia, unidadesenpedido) FROM stdin;
\.
COPY compras.productos (idproducto, nomproducto, idproveedor, idcateria, cantxunidad, preciounidad, unidadesenexistencia, unidadesenpedido) FROM '$$PATH$$/3397.dat';

--
-- Data for Name: proveedores; Type: TABLE DATA; Schema: compras; Owner: postgres
--

COPY compras.proveedores (idproveedor, nomproveedor, dirproveedor, nomcontacto, carcontacto, idpais, fonoproveedor, faxproveedor) FROM stdin;
\.
COPY compras.proveedores (idproveedor, nomproveedor, dirproveedor, nomcontacto, carcontacto, idpais, fonoproveedor, faxproveedor) FROM '$$PATH$$/3396.dat';

--
-- Data for Name: cargos; Type: TABLE DATA; Schema: rrhh; Owner: postgres
--

COPY rrhh.cargos (idcargo, descargo) FROM stdin;
\.
COPY rrhh.cargos (idcargo, descargo) FROM '$$PATH$$/3398.dat';

--
-- Data for Name: distritos; Type: TABLE DATA; Schema: rrhh; Owner: postgres
--

COPY rrhh.distritos (iddistrito, nomdistrito) FROM stdin;
\.
COPY rrhh.distritos (iddistrito, nomdistrito) FROM '$$PATH$$/3399.dat';

--
-- Data for Name: empleados; Type: TABLE DATA; Schema: rrhh; Owner: postgres
--

COPY rrhh.empleados (idempleado, apeempleado, nomempleado, fecnac, dirempleado, iddistrito, fonoempleado, idcargo, feccontrata) FROM stdin;
\.
COPY rrhh.empleados (idempleado, apeempleado, nomempleado, fecnac, dirempleado, iddistrito, fonoempleado, idcargo, feccontrata) FROM '$$PATH$$/3400.dat';

--
-- Data for Name: clientes; Type: TABLE DATA; Schema: ventas; Owner: postgres
--

COPY ventas.clientes (idcliente, nomcliente, dircliente, idpais, fonocliente) FROM stdin;
\.
COPY ventas.clientes (idcliente, nomcliente, dircliente, idpais, fonocliente) FROM '$$PATH$$/3395.dat';

--
-- Data for Name: paises; Type: TABLE DATA; Schema: ventas; Owner: postgres
--

COPY ventas.paises (idpais, nombrepais) FROM stdin;
\.
COPY ventas.paises (idpais, nombrepais) FROM '$$PATH$$/3394.dat';

--
-- Data for Name: pedidoscabe; Type: TABLE DATA; Schema: ventas; Owner: postgres
--

COPY ventas.pedidoscabe (idpedido, idcliente, idempleado, fechapedido, fechaentrega, fechaenvio, enviopedido, cantidapedido, destinatario, dirdestinatario, ciudestinatario, refdestnatario, depdestinatario, paidestinatario) FROM stdin;
\.
COPY ventas.pedidoscabe (idpedido, idcliente, idempleado, fechapedido, fechaentrega, fechaenvio, enviopedido, cantidapedido, destinatario, dirdestinatario, ciudestinatario, refdestnatario, depdestinatario, paidestinatario) FROM '$$PATH$$/3401.dat';

--
-- Data for Name: pedidosdeta; Type: TABLE DATA; Schema: ventas; Owner: postgres
--

COPY ventas.pedidosdeta (idpedido, idproducto, preciounidad, cantidad, descuento) FROM stdin;
\.
COPY ventas.pedidosdeta (idpedido, idproducto, preciounidad, cantidad, descuento) FROM '$$PATH$$/3402.dat';

--
-- Name: categorias categorias_pkey; Type: CONSTRAINT; Schema: compras; Owner: postgres
--

ALTER TABLE ONLY compras.categorias
    ADD CONSTRAINT categorias_pkey PRIMARY KEY (idcateria);


--
-- Name: productos productos_pkey; Type: CONSTRAINT; Schema: compras; Owner: postgres
--

ALTER TABLE ONLY compras.productos
    ADD CONSTRAINT productos_pkey PRIMARY KEY (idproducto);


--
-- Name: proveedores proveedores_pkey; Type: CONSTRAINT; Schema: compras; Owner: postgres
--

ALTER TABLE ONLY compras.proveedores
    ADD CONSTRAINT proveedores_pkey PRIMARY KEY (idproveedor);


--
-- Name: cargos cargos_pkey; Type: CONSTRAINT; Schema: rrhh; Owner: postgres
--

ALTER TABLE ONLY rrhh.cargos
    ADD CONSTRAINT cargos_pkey PRIMARY KEY (idcargo);


--
-- Name: distritos distritos_pkey; Type: CONSTRAINT; Schema: rrhh; Owner: postgres
--

ALTER TABLE ONLY rrhh.distritos
    ADD CONSTRAINT distritos_pkey PRIMARY KEY (iddistrito);


--
-- Name: empleados empleados_pkey; Type: CONSTRAINT; Schema: rrhh; Owner: postgres
--

ALTER TABLE ONLY rrhh.empleados
    ADD CONSTRAINT empleados_pkey PRIMARY KEY (idempleado);


--
-- Name: clientes clientes_pkey; Type: CONSTRAINT; Schema: ventas; Owner: postgres
--

ALTER TABLE ONLY ventas.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (idcliente);


--
-- Name: paises paises_pkey; Type: CONSTRAINT; Schema: ventas; Owner: postgres
--

ALTER TABLE ONLY ventas.paises
    ADD CONSTRAINT paises_pkey PRIMARY KEY (idpais);


--
-- Name: pedidoscabe pedidoscabe_pkey; Type: CONSTRAINT; Schema: ventas; Owner: postgres
--

ALTER TABLE ONLY ventas.pedidoscabe
    ADD CONSTRAINT pedidoscabe_pkey PRIMARY KEY (idpedido);


--
-- Name: productos productos_idcateria_fkey; Type: FK CONSTRAINT; Schema: compras; Owner: postgres
--

ALTER TABLE ONLY compras.productos
    ADD CONSTRAINT productos_idcateria_fkey FOREIGN KEY (idcateria) REFERENCES compras.categorias(idcateria);


--
-- Name: productos productos_idproveedor_fkey; Type: FK CONSTRAINT; Schema: compras; Owner: postgres
--

ALTER TABLE ONLY compras.productos
    ADD CONSTRAINT productos_idproveedor_fkey FOREIGN KEY (idproveedor) REFERENCES compras.proveedores(idproveedor);


--
-- Name: proveedores proveedores_idpais_fkey; Type: FK CONSTRAINT; Schema: compras; Owner: postgres
--

ALTER TABLE ONLY compras.proveedores
    ADD CONSTRAINT proveedores_idpais_fkey FOREIGN KEY (idpais) REFERENCES ventas.paises(idpais);


--
-- Name: empleados empleados_idcargo_fkey; Type: FK CONSTRAINT; Schema: rrhh; Owner: postgres
--

ALTER TABLE ONLY rrhh.empleados
    ADD CONSTRAINT empleados_idcargo_fkey FOREIGN KEY (idcargo) REFERENCES rrhh.cargos(idcargo);


--
-- Name: empleados empleados_iddistrito_fkey; Type: FK CONSTRAINT; Schema: rrhh; Owner: postgres
--

ALTER TABLE ONLY rrhh.empleados
    ADD CONSTRAINT empleados_iddistrito_fkey FOREIGN KEY (iddistrito) REFERENCES rrhh.distritos(iddistrito);


--
-- Name: clientes clientes_idpais_fkey; Type: FK CONSTRAINT; Schema: ventas; Owner: postgres
--

ALTER TABLE ONLY ventas.clientes
    ADD CONSTRAINT clientes_idpais_fkey FOREIGN KEY (idpais) REFERENCES ventas.paises(idpais);


--
-- Name: pedidoscabe pedidoscabe_idcliente_fkey; Type: FK CONSTRAINT; Schema: ventas; Owner: postgres
--

ALTER TABLE ONLY ventas.pedidoscabe
    ADD CONSTRAINT pedidoscabe_idcliente_fkey FOREIGN KEY (idcliente) REFERENCES ventas.clientes(idcliente);


--
-- Name: pedidoscabe pedidoscabe_idempleado_fkey; Type: FK CONSTRAINT; Schema: ventas; Owner: postgres
--

ALTER TABLE ONLY ventas.pedidoscabe
    ADD CONSTRAINT pedidoscabe_idempleado_fkey FOREIGN KEY (idempleado) REFERENCES rrhh.empleados(idempleado);


--
-- Name: pedidosdeta pedidosdeta_idpedido_fkey; Type: FK CONSTRAINT; Schema: ventas; Owner: postgres
--

ALTER TABLE ONLY ventas.pedidosdeta
    ADD CONSTRAINT pedidosdeta_idpedido_fkey FOREIGN KEY (idpedido) REFERENCES ventas.pedidoscabe(idpedido);


--
-- Name: pedidosdeta pedidosdeta_idproducto_fkey; Type: FK CONSTRAINT; Schema: ventas; Owner: postgres
--

ALTER TABLE ONLY ventas.pedidosdeta
    ADD CONSTRAINT pedidosdeta_idproducto_fkey FOREIGN KEY (idproducto) REFERENCES compras.productos(idproducto);


--
-- PostgreSQL database dump complete
--

